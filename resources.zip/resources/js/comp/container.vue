<template>
    <v-app>
        <!-- Navigation Drawer -->
        <v-navigation-drawer v-model="drawer" floating app class="menu-left rounded-right-menu shadow"
            color="rgba(0, 0, 0, 0.87)" width="260" absolute>
            <!-- Logo -->
            <v-list-item>
                <v-list-item-content class="d-flex justify-center">
                    <v-img src="../../img/logo.png" width="80%" max-height="100px" contain></v-img>
                </v-list-item-content>
            </v-list-item>

            <!-- Title -->
            <v-list-item class="text-center py-4">
                <v-list-item-title class="text-h6 font-weight-bold text-white">Manuelito´s</v-list-item-title>
            </v-list-item>

            <!-- Divider -->
            <v-divider class="border-opacity-100"></v-divider>

            <!-- Menu Items -->

            <v-list density="compact" nav>
                <v-list-item v-for="item in items" :key="item.title" :to="item.ruta" class="menu-item" link
                    :class="{ 'selected-item': selectedItem === item.title }" @click="selectedItem = item.title">
                    <!-- Flexbox for aligning icon and text -->
                    <v-row class="d-flex align-center" no-gutters>
                        <v-col class="d-flex align-center" cols="auto">
                            <v-icon color="white">{{ item.icon }}</v-icon>
                        </v-col>
                        <v-col class="d-flex align-center" cols="auto">
                            <v-list-item-title class="text-body-1 font-weight-medium white--text">{{ item.title
                                }}</v-list-item-title>
                        </v-col>
                    </v-row>
                </v-list-item>
            </v-list>
        </v-navigation-drawer>

        <!-- App Bar -->
        <v-app-bar color="#4caf50" elevation="6" class="rounded-bar mx-3 mt-3" absolute>
            <v-toolbar-title class="text-h6 white--text">Panel de Control</v-toolbar-title>
        </v-app-bar>

        <!-- Main Content -->
        <v-main>
            <v-container fluid>
                <!-- Vue Router View -->
                <router-view></router-view>
            </v-container>
        </v-main>


    </v-app>
</template>

<script>
export default {
    data() {
        return {
            drawer: true, // Controla la visibilidad del menú
            selectedItem: null, // Controla el ítem seleccionado
            items: [
                { title: "PRODUCTOS", icon: "mdi-cow", ruta: "productos" },
                { title: "INVENTARIO", icon: "mdi-book-open", ruta: "inventarios" },
                { title: "REPORTE", icon: "mdi-chart-timeline", ruta: "reportes" },
            ],
            loading: false,
        };
    },
};
</script>

<style scoped>
/* Menú flotante con solo las puntas derechas redondeadas */
.rounded-right-menu {
    position: fixed;
    left: 20px;
    top: 20px;
    bottom: 20px;
    z-index: 10;
    width: 260px;
    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15);
    border-top-right-radius: 20px;
    /* Solo esquina superior derecha redondeada */
    border-bottom-right-radius: 20px;
    /* Solo esquina inferior derecha redondeada */
    background-color: rgba(0, 0, 0, 0.87);
    /* Fondo más oscuro */
}

/* Barra superior flotante con esquinas redondeadas */
.rounded-bar {
    border-radius: 20px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.15);
    background-color: #2C3E50;
    /* Azul oscuro */
}

/* Estilo del ítem de menú */
.menu-item {
    transition: background-color 0.3s, padding-left 0.3s;
    /* Transiciones suaves */
    padding-left: 20px;
    padding-right: 20px;
    display: flex;
    align-items: center;
}

/* Fondo gris con mayor transparencia al pasar sobre el ítem del menú */
.menu-item:hover {
    background-color: rgba(169, 169, 169, 0.3);
    /* Gris más transparente */
    color: #2C3E50;
    /* Texto oscuro al hacer hover */
}

/* Fondo del contenedor principal */
.v-main {
    background-color: #f5f5f5;
    /* Gris suave */
    min-height: 100vh;
    padding-top: 80px;
    /* Asegura espacio para la barra superior */
}

/* Colores del texto principal */
.text-primary {
    color: #2C3E50;
    /* Azul oscuro */
}

/* Colores del texto de los ítems del menú */
.v-list-item-title {
    color: #FFFFFF;
    /* Blanco para los títulos del menú */
}

/* Fondo y color de la barra superior */
.v-toolbar-title {
    color: #ffffff;
    /* Blanco */
}

/* Color de los íconos */
.v-icon {
    color: #FFFFFF;
    /* Blanco */
}

.white--text {
    color: white !important;
}

/* Personalización de los elementos seleccionados */
.selected-item {
    background-color: #4caf50 !important;
    /* Color verde al seleccionar el ítem */
    color: white !important;
    /* Texto blanco */
}

/* Divisor más grueso y visible */
.white-divider {
    background-color: #FFFFFF;
    /* Color blanco para el v-divider */
    height: 200px;
    /* Hace el divisor más grueso */
}

/* Separación entre el ícono y el texto */
.menu-item .v-row {
    margin-left: 10px;
    /* Separación entre ícono y texto */
}
</style>
